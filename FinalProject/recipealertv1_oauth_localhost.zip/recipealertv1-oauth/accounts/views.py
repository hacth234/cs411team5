from django.shortcuts import render, redirect
from django.urls import reverse

# Create your views here.
from django.http import HttpResponse
from django.forms import inlineformset_factory #inlineformset_factory allows us to create multiple forms within one form

from .models import *
from .forms import *
from .filters import OrderFilter
from django.contrib.auth.forms import UserCreationForm #for authentication stuff
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required #allows us to restrict views, usually done with middleware but django makes it easy
                                                            #for views we want to restricted
from .decorators import *

from django.contrib import messages #tells and give users responses for forms and etc

from django.contrib.auth.models import Group #importing the group model of django
#all the order queries will be taken care up in view.py

import json

import requests
#from django.urls import reverse
from pandas.io.json import json_normalize #so we can easily normalize json data
import pandas as pd
from django.http import JsonResponse

# @allowed_users(allowed_roles=['admin'])ss
#decorator for restricted access stuff, only if user is logged in, only if user is in the allowed group
# @login_required(login_url='login') #makes it so our user must be logged in to access the homepage. if user isnt login send it to the url 'login'
# @admin_only
def home(request):
    # orders = Order.objects.all()
    # customers = Customer.objects.all()



    # # user_saved_recipe = RecipeSavedProfile.objects.filter()

    # #context = {'orders':orders, 'customers':customers} #a dictiona0ry for context variables

    # total_customers = customers.count()

    # # total_orders = orders.count() #total_orders = Order.objects.all()
    # # delivered = orders.filter(status='Delivered') #filter the order for delivered only
    # #  pending = orders.filter(status='Pending')


    # total_orders = orders.count() #total_orders = Order.objects.all()
    # delivered = orders.filter(status='Delivered').count() #filter the order for delivered only. count of them
    # pending = orders.filter(status='Pending').count() #filter the order for delivered only. count of them
    # context = {'orders':orders, 'customers':customers, 'total_orders':total_orders, 'delivered':delivered, 'pending':pending} #a dictiona0ry for context variables

    url = reverse('user_page2')
    # return render(request, 'accounts/dashboard.html', context)
    return redirect(url)

@login_required(login_url='login')
@allowed_users(allowed_roles=['admin'])
def products(request):
    products = Product.objects.all() #query the database for all the products



    return render(request, 'accounts/products.html', {'products':products}) #we pass in the products:products in this dictionary so that we can call it in the html templates this way


# def customer(request, pk):
#     customer = Customer.objects.get(id=pk)
#     orders = customer.order_set.all() #way of querying all the child object of orders from customer
#     order_count = orders.count()
    
#     context = {'customer':customer, 'orders':orders, 'order_count':order_count}

#     # return render(request, 'accounts/customer.html')
#     return render(request, 'accounts/customer.html', context)


@login_required(login_url='login')
@allowed_users(allowed_roles=['admin'])
def customer(request, pk):
    customer = Customer.objects.get(id=pk)
    orders = customer.order_set.all() #way of querying all the child object of orders from customer
    order_count = orders.count()
    

    # myFilter = OrderFilter()
    myFilter = OrderFilter(request.GET, queryset=orders) #data gets rendered and thrown into the filter, if there are any parameters it filters it down
    orders = myFilter.qs #remake the varaible with the filtered down data. by getting the queryset of the filtered data


    context = {'customer':customer, 'orders':orders, 'order_count':order_count, 'myFilter':myFilter}

    # return render(request, 'accounts/customer.html')
    return render(request, 'accounts/customer.html', context)


# def createOrder(request):

#     form = OrderForm()
#     if (request.method == 'POST'):
#         print('Posting', request.POST)

#         form = OrderForm(request.POST)
#         if form.is_valid():
#             #if form is valid 
#             form.save() #form will be saved in the database automatically
#             return redirect('/') #go back one post
#     context = {'form':form}
#     return render(request, 'accounts/order_form.html', context)

# def createOrder(request, pk):
#     customer = Customer.objects.get(id=pk)

#     form = OrderForm()
#     if (request.method == 'POST'):
#         print('Posting', request.POST)

#         form = OrderForm(request.POST)
#         if form.is_valid():
#             #if form is valid 
#             form.save() #form will be saved in the database automatically
#             return redirect('/') #go back one post
#     context = {'form':form}
#     return render(request, 'accounts/order_form.html', context)


@login_required(login_url='login')
@allowed_users(allowed_roles=['admin'])
def createOrder(request, pk):
    OrderFormSet = inlineformset_factory(Customer, Order, fields=('product','status'), extra=10) #takes in both Customer and Order model, extra gives extra form fields to show
    customer = Customer.objects.get(id=pk)

    #form = OrderForm(initial={'customer':customer})#we init customer to be the customer object that holds that primary key, we clicked this person to create a form for.
    #formset = OrderFormSet(instance=customer) #make that formset's instance take in this customer instance

    #formset = OrderFormSet(instance=customer)
    formset = OrderFormSet(queryset=Order.objects.none(), instance=customer) #queryset orderobjectnone is saying if there is object there dont reference them or show them on initial mock up of the page

    if (request.method == 'POST'):
        print('Posting', request.POST)

        #form = OrderForm(request.POST)
        formset = OrderFormSet(request.POST, instance=customer)
        if formset.is_valid():
            #if form is valid 
            formset.save() #form will be saved in the database automatically
            return redirect('/') #go back one post
    #context = {'form':form}
    context = {'formset':formset}
    return render(request, 'accounts/order_form.html', context)

@login_required(login_url='login')
@allowed_users(allowed_roles=['admin'])
def updateOrder(request, pk):

    order = Order.objects.get(id=pk)


    form = OrderForm(instance=order) #order form instance is going to be equal to that specified order we want to edit

    if (request.method == 'POST'):
        print('Posting', request.POST)

        form = OrderForm(request.POST, instance=order) #save it as that instance on the post
        if form.is_valid():
            #if form is valid 
            form.save() #form will be saved in the database automatically
            return redirect('/') #go back one post
    context = {'form':form}
    return render(request, 'accounts/order_form.html', context)

@login_required(login_url='login')
@allowed_users(allowed_roles=['admin'])
def deleteOrder(request, pk):
    order = Order.objects.get(id=pk)
    context = {'item':order}
    if (request.method == 'POST'):
        order.delete()
        return redirect('/') #go back one post
    return render(request, 'accounts/delete.html', context)



# def products(request):
#     return HttpResponse('products')

# def costumer(request):
#     return HttpResponse('customer')







#decorator for allowing it only to be accessible when the user is not logged in
@unauthenticated_user
def registerPage(request):

    # #if user is logged in just log the user in, to restrict access to login and registration page for logged in users
    # if request.user.is_authenticated:
    #     #we can access user this way because django does it for us in request
    #     return redirect('home') #redirect user to home page


    #else just log the user in
    #form = UserCreationForm() #the old one django provides
    form = CreateUserForm() #the one with the extra fields we want

    if request.method == 'POST':
        #form = UserCreationForm(request.POST)
        form = CreateUserForm(request.POST)

        if form.is_valid():
            user = form.save() #django does the user creation for us in this form, will check for username and hash the password for us
            username = form.cleaned_data.get('username') #gets field of the form for username
            email = form.cleaned_data.get('email')

            group = Group.objects.get(name='customer') #get the customer group from our django admin models
            user.groups.add(group) #add that group instance of customer to the user

            #assigning customer to our newly created user so it can do the functionality of a customer model
            Customer.objects.create(user=user) #create a customer object for this user by setting the field user in Customer object to user

            theCustomer = Customer.objects.get(user=user) #my addition to editing that object
            theCustomer.name = username 
            theCustomer.email = email
            theCustomer.save()

            messages.success(request, 'Account was successfully created for ' + username)
            return redirect('login')
    context = {'form':form}
    return render(request, 'accounts/register.html', context)


#not used anymore but was an extra step for checks
def oauthRedirectPage(request):
    form = CreateUserForm() #the one with the extra fields we want


    theuser = request.user #get the user of the request.

    theCustomerCount = Customer.objects.filter(user=theuser).count()
    if (Customer.objects.filter(user=theuser).count() == 0):
        #if we dont get a customer object by with this instace of an account and user
        #we need to add the Customer model relationship to this user
        # print()

        group = Group.objects.get(name='customer')
        request.user.groups.add(group) #add the customer group to user. 

        #make sure to make an object for this account under this insance.
        Customer.objects.create(user=theuser)
        theCustomer = Customer.objects.get(user=theuser) #get that newly created customer object
        theCustomer.name = str(request.user.first_name) + " " + str(request.user.last_name) #get the first and last name of the user
        theCustomer.email = request.user.email
        theCustomer.save() #save this object

    # context = {'form':form}
    url = reverse('user_page')
    #redirect to login page
    # return render(request, 'accounts/oauthregister.html', context)
    return redirect(url)




@unauthenticated_user
def loginPage(request):
    # #if user is logged in just log the user in, to restrict access to login and registration page for logged in users
    # if request.user.is_authenticated:
    #     #we can access user this way because django does it for us in request
    #     return redirect('home') #redirect user to home page


    if request.method == 'POST':
        username = request.POST.get('username') #get the value from the form field username from the post
        password = request.POST.get('password') #get the value form the form field password from the post

        user = authenticate(request, username=username, password=password) #using django authentication it checks with it in the database

        if user is not None:
            #if user exists and it authenticated with a non None- meaning password matches with the username given
            #authenticate test passed
            #then login using django built in login 
            login(request, user)
            return redirect('home')
        else:
            messages.info(request, 'Username and/or Password is invalid')
        
    context = {}
    return render(request, 'accounts/login.html', context)

def logoutUser(request):
    logout(request)
    return redirect('login')


@login_required(login_url='login')
# @allowed_users(allowed_roles=['user'])
def userPage(request):

    theuser = request.user #get the user of the request.

    theCustomerCount = Customer.objects.filter(user=theuser).count()
    if (Customer.objects.filter(user=theuser).count() == 0):
        #if we dont get a customer object by with this instace of an account and user
        #we need to add the Customer model relationship to this user
        # print()

        group = Group.objects.get(name='customer')
        request.user.groups.add(group) #add the customer group to user. 

        #make sure to make an object for this account under this insance.
        Customer.objects.create(user=theuser)
        theCustomer = Customer.objects.get(user=theuser) #get that newly created customer object
        theCustomer.name = str(request.user.first_name) + " " + str(request.user.last_name) #get the first and last name of the user
        theCustomer.email = request.user.email
        theCustomer.save() #save this object


    orders = request.user.customer.order_set.all() #allows us to get from the one to one relationship (set in model) user to customer to get all the orders as a set from the customer


    user_name = request.user.customer.name

    total_orders = orders.count() #total_orders = Order.objects.all()
    delivered = orders.filter(status='Delivered').count() #filter the order for delivered only. count of them
    pending = orders.filter(status='Pending').count() #filter the order for delivered only. count of them

    #
    saved_recipe_profile = request.user.customer.recipesavedprofile_set.all()
    saved_recipe_profile_count = saved_recipe_profile.count()

    saved_recipe_database = RecipeSavedDatabase.objects.filter()
    saved_recipe_database_count = saved_recipe_database.count()

    total_users = Customer.objects.filter().count()


    context = {'orders':orders, 'total_orders':total_orders, 'delivered':delivered, 'pending':pending, "saved_recipe_profile": saved_recipe_profile, "saved_recipe_profile_count": saved_recipe_profile_count, 
    "saved_recipe_database": saved_recipe_database, "saved_recipe_database_count": saved_recipe_database_count, "total_users": total_users, "user_name": user_name
    }
    return render(request, 'accounts/user.html', context)

@allowed_users(allowed_roles=['user'])
def userPage2(request):

    theuser = request.user #get the user of the request.

    theCustomerCount = Customer.objects.filter(user=theuser).count()
    if (Customer.objects.filter(user=theuser).count() == 0):
        #if we dont get a customer object by with this instace of an account and user
        #we need to add the Customer model relationship to this user
        # print()

        group = Group.objects.get(name='customer')
        request.user.groups.add(group) #add the customer group to user. 

        #make sure to make an object for this account under this insance.
        Customer.objects.create(user=theuser)
        theCustomer = Customer.objects.get(user=theuser) #get that newly created customer object
        theCustomer.name = str(request.user.first_name) + " " + str(request.user.last_name) #get the first and last name of the user
        theCustomer.email = request.user.email
        theCustomer.save() #save this object


    orders = request.user.customer.order_set.all() #allows us to get from the one to one relationship (set in model) user to customer to get all the orders as a set from the customer


    user_name = request.user.customer.name

    total_orders = orders.count() #total_orders = Order.objects.all()
    delivered = orders.filter(status='Delivered').count() #filter the order for delivered only. count of them
    pending = orders.filter(status='Pending').count() #filter the order for delivered only. count of them

    #
    saved_recipe_profile = request.user.customer.recipesavedprofile_set.all()
    saved_recipe_profile_count = saved_recipe_profile.count()

    saved_recipe_database = RecipeSavedDatabase.objects.filter()
    saved_recipe_database_count = saved_recipe_database.count()

    total_users = Customer.objects.filter().count()


    context = {'orders':orders, 'total_orders':total_orders, 'delivered':delivered, 'pending':pending, "saved_recipe_profile": saved_recipe_profile, "saved_recipe_profile_count": saved_recipe_profile_count, 
    "saved_recipe_database": saved_recipe_database, "saved_recipe_database_count": saved_recipe_database_count, "total_users": total_users, "user_name": user_name
    }
    return render(request, 'accounts/user.html', context)

# @login_required(login_url='login')
@allowed_users(allowed_roles=['customer'])
def accountSettings(request):

    #user = request.user #gets us the logged in user at anypoint in time.
    customer = request.user.customer #get the user's customer form to access its customer's form fields
    #render the customer form
    form = CustomerForm(instance=customer)


    #now to update it through posting
    if request.method == 'POST':
        form = CustomerForm(request.POST, request.FILES, instance=customer) #request.FILES takes whatever file it comes with it too
        if form.is_valid():
            form.save()
    context = {'form':form}
    return render(request, 'accounts/account_settings.html', context)


def searchRecipe(request):
    """ Search for a recipe based on form inputs from the recipe puppy api"""
    form = SearchRecipeForm()

    #make it empty context first with all the same variables so we can show on same page
    empty_symptom_form = SearchSymptomForm()


    ingredient = ""
    dish = ""
    title_lists = []
    href_lists = []
    ingredients_lists = []
    ingredients_lists_list = []
    result_zipped = zip(title_lists, href_lists, ingredients_lists, ingredients_lists_list)
    context = {'form':form, 'ingredient':ingredient, 'dish':dish, "title_lists":title_lists, "href_lists":href_lists, "ingredients_lists":ingredients_lists, "result_zipped":result_zipped, "symptom_form": empty_symptom_form} #remake context, make a new form
    if request.method == 'POST':
        #form = UserCreationForm(request.POST)
        form = SearchRecipeForm(request.POST)

        if form.is_valid():

            # render(request, 'accounts/recipe_search.html', context)
            #grab the form ingredient and dish

            ingredient = form.cleaned_data.get('ingredient')
            dish = form.cleaned_data.get('dishname')

            url = f"http://www.recipepuppy.com/api/?i=""&q=""&p=1"
            if (dish != None and ingredient != None):
                url = f"http://www.recipepuppy.com/api/?i={ingredient}&q={dish}&p=1"
                print(url)
            elif (dish != None and ingredient == None):
                url = f"http://www.recipepuppy.com/api/?q={dish}&p=1"
                print(url)
            elif (ingredient != None and dish == None):
                url = f"http://www.recipepuppy.com/api/?i={ingredient}&p=1"
                print(url)
            
            payload={}

            # headers = {
            #     'Cookie': 'kohanasession=5a05ae87b671e72a606e5c6b1fda500f; kohanasession_data=c2Vzc2lvbl9pZHxzOjMyOiI1YTA1YWU4N2I2NzFlNzJhNjA2ZTVjNmIxZmRhNTAwZiI7dG90YWxfaGl0c3xpOjE7X2tmX2ZsYXNoX3xhOjA6e311c2VyX2FnZW50fHM6MjI6IlBvc3RtYW5SdW50aW1lLzcuMjYuMTAiO2lwX2FkZHJlc3N8czoxMjoiOTguMjI5LjczLjI4IjtsYXN0X2FjdGl2aXR5fGk6MTYxNjcxNjA3NDs%3D'
            #     }
            # headers = {
            # 'Cookie': 'kohanasession=6ef039996c113872197775ac10e52255; kohanasession_data=c2Vzc2lvbl9pZHxzOjMyOiI2ZWYwMzk5OTZjMTEzODcyMTk3Nzc1YWMxMGU1MjI1NSI7dG90YWxfaGl0c3xpOjI7X2tmX2ZsYXNoX3xhOjA6e311c2VyX2FnZW50fHM6MjI6IlBvc3RtYW5SdW50aW1lLzcuMjYuMTAiO2lwX2FkZHJlc3N8czoxMjoiOTguMjI5LjczLjI4IjtsYXN0X2FjdGl2aXR5fGk6MTYxNjczMTM5NDs%3D'
            # }
            # response = requests.request("GET", url, headers=headers, data=payload)
            # response_html = """
            #         %s
            # """ % response.text

            response = requests.get(url) #gets the response
            # r_json = response.json() #turns response into json
            # y = json.loads(r_json) #loads it based on the key value
            # y = json.dumps(r_json)

            json_data = json.loads(response.text)

            # ingredients = y["ingredients"] #grabs all the ingredients into string 
            results = json_data["results"] #grab all the results
            # splitted_results = results.split(',') #split it based on comma so we get list of json data
            #try turning all results into a string list?

            #get dish name
            #get recipe ingredients parse all the json stuff

            normalized_data = pd.json_normalize(results, max_level=0) #just make it a pandas dataframe that is normalized

            title_lists = []
            href_lists = []
            ingredients_lists = []
            ingredients_lists_list = []

            # for result in splitted_results:
            #     #grab ingredients ls
            #     result_json = json.loads(result)
            #     title_lists.append(result_json["title"])
            #     href_lists.append(result_json["href"])
            #     ingredients_lists.append(result_json["ingredients"])


            # for title in normalized_data["title"]:
            #     title_lists.append(title)

            # for href in normalized_data["href"]:
            #     href_lists.append(href)

            # for ing in normalized_data["ingredients"]:
            #     ingredients_lists.append(ing)

            for index, row in normalized_data.iterrows():
                title_lists.append(row['title'])
                href_lists.append(row['href'])
                ingredients_lists.append(row['ingredients'])

                ingredient_splitted = row['ingredients'].split(',') #make string lists of ingredients so we can use for symptom form

                ingredient_splitted_notrialing = []
                for i in ingredient_splitted:
                    ingredient_splitted_notrialing.append(i.strip())

                # ingredients_lists_list.append(ingredient_splitted)
                ingredients_lists_list.append(ingredient_splitted_notrialing)

            
            result_zipped = zip(title_lists, href_lists, ingredients_lists, ingredients_lists_list)
            context = {'form':form, 'ingredient':ingredient, 'dish':dish, "title_lists":title_lists, "href_lists":href_lists, "ingredients_lists":ingredients_lists, "result_zipped":result_zipped, "symptom_form": empty_symptom_form} #remake context, make a new form

            #or render my http response here? without depending on the html template?
            # return render(request, 'accounts/recipe_display_all.html', context) #direct to new page or it stays on that page
            return render(request, 'accounts/recipe_search.html', context)

    #show multiple recipe and clicking a button associated with that recipe button will display that recipe
    #in display recipe, lets just do like 1 page worth of stuff
    #on search it will make the databasing for all of the stuff the json shows, if it is not already in the database.

    return render(request, 'accounts/recipe_search.html', context)


# def searchRecipeAdvanced(request):

#     form = SearchRecipeForm()

#     context = {'form':form}
#     if request.method == 'POST':
#         form = SearchRecipeForm(request.POST)

#         if form.is_valid():

#             ingredient = form.cleaned_data.get('ingredient')
#             dish = form.cleaned_data.get('dishname')
#             url = f"http://www.recipepuppy.com/api/?i={ingredient}&q={dish}&p=1"
#             payload={}

#             response = requests.get(url) 
#             json_data = json.loads(response.text)
#             results = json_data["results"] #grab all the results

#             normalized_data = pd.json_normalize(results, max_level=0) #just make it a pandas dataframe that is normalized

#             title_lists = []
#             href_lists = []
#             ingredients_lists = []
#             ingredients_lists_list = []

#             for index, row in normalized_data.iterrows():
#                 title_lists.append(row['title'])
#                 href_lists.append(row['href'])
#                 ingredients_lists.append(row['ingredients'])

#                 ingredient_splitted = row['ingredients'].split(',') #make string lists of ingredients so we can use for symptom form
#                 ingredients_lists_list.append(ingredient_splitted)
            
#             result_zipped = zip(title_lists, href_lists, ingredients_lists, ingredients_lists_list)

#             empty_symptom_form = SearchSymptomForm()
#             context = {'form':form, 'ingredient':ingredient, 'dish':dish, "title_lists":title_lists, "href_lists":href_lists, "ingredients_lists":ingredients_lists, "result_zipped":result_zipped, "symptom_form": empty_symptom_form} #remake context, make a new form

#             #or render my http response here? without depending on the html template?
#             return render(request, 'accounts/recipe_display_all.html', context) #direct to new page or it stays on that page?
#     return render(request, 'accounts/recipe_search.html', context)



def displayAllRecipes(request):
    #database saving based on search.
    #will query database to see if exist, if not exist based on url then add it.

    #make the search display all the recipe it has, then if user wants to save, it will save based on the associated form.
    #we will query records from the 
    #context url will be the matcher for the button click, will query database to search for this one.
    context = {}
    return render(request, 'accounts/recipe_display_all.html', context)


#not used
def displayRecipe(request):

    #this is the click one to show
    #recipe_display will include the form/search symptom search bar
    context = {}
    return render(request, 'accounts/recipe_display.html', context)



#checks if a key is present
def is_json_key_present(json, key):
    try:
        buf = json[key]
    except KeyError:
        return False

    return True


#todo
def searchSymptom(request):
    """ Search for symptoms on a recipe through the fda api """
    #on the same place as the displayRecipe 
    #just post the warning stuff here.
    #loops through all the ingredients and check if any of them cause any symptoms listed throguh the fda. Query like 100 or 200 fda ones.
    

    #grab database objects too? and check base on the url. If same we incorporate a user recommendation.
    context = {}
    if request.method == 'POST':
        # ingredientlist = request.POST['ingredientlist']

        symptom = request.POST['symptom']
        ing_string = request.POST['ing_string']
        title =  request.POST['titles']
        ref = request.POST['refs']

        ingredient_splitted = ing_string.split(',') #make string lists of ingredients so we can use for symptom form

        ingredientlist = []
        for i in ingredient_splitted:
            #organize the list
            ingredientlist.append(i.strip())

        foodIngredientWarnings = 0
        totalWarnings = 0
        totalSearches = 0

        #We found x ingredients that cause {symptom}.
        #We found a total of y warnings that cause {symptom}.

        ct = 0
        #loop ingredients and set up json calls


        warning_ingredientLs = {}
        result_count = {}
        warning_ingredientCheckLs = []
        for ingredient in ingredientlist:
            # break
            # if (ct == 5):
            #     break
            # print("Here is an ingredient: " + ingredient)

            #BUILD url and json objects to fda based on the ingredient
            url = f"https://api.fda.gov/food/event.json?search={ingredient}&limit=100"
            response = requests.get(url)
            json_data = json.loads(response.text)

            # print(response.text)
            if (not is_json_key_present(json_data, "results")):
                continue #skip/continue if there is no results field, no result for this ingredient.
            results = json_data["results"] #grab all the results
            normalized_data = pd.json_normalize(results, max_level=0)

            result_count[ingredient] = 0
            for index, row in normalized_data.iterrows():

                # print(row)
                # if(is_json_key_present(row, "result")):
                #     print("yes")
                # else:
                #     print("not exist")
                #     continue

                #look at ones with the result keys only
                symptomToUpper = symptom.upper()
                if (not is_json_key_present(row, "reactions")):
                    continue #skip this record if there is no reactions field

                totalSearches += 1
                print(row)
                # ct += 1
                symptomWarnings = row['reactions']
                result_count[ingredient] += 1

                print(symptomWarnings)
                print(symptomToUpper)

                if (str(symptomToUpper) in symptomWarnings):
                    #if this symptom is in the reactions side effect throw a warning count and update our warnings to the user
                    if (ingredient in warning_ingredientCheckLs):
                        #if we already warned about this ingredient
                        totalWarnings += 1
                        warning_ingredientLs[ingredient] += 1 
                    else:
                        #if we didnt warn about this ingredient yet, do so now. Warn the ingredient count, total warning and ingredient_isWarning to True
                        warning_ingredientLs[ingredient] = 1
                        warning_ingredientCheckLs.append(ingredient) #append the ingredient for easy searching.
                        # print(warning_ingredientCheckLs)
                        totalWarnings += 1
                        foodIngredientWarnings += 1 #new food ingredient to warn about
                
            print(totalWarnings)
            print(foodIngredientWarnings)
            print(warning_ingredientCheckLs)
            # print(warning_ingredientLs)
        
        
        warning_ingredient_amount_ls = []
        picture_src_ls = []
        recommend_ls = []
        for ingred in warning_ingredientCheckLs:
            warning_ingredient_amount_ls.append(warning_ingredientLs[ingred])
            url_src = f"https://spoonacular.com/cdn/ingredients_500x500/{ingred}.jpg"
            picture_src_ls.append(url_src)
            #check against a standard deviation of 18 percent
            resultscount = result_count[ingred]
            if (result_count != 0):
                thePercent = warning_ingredientLs[ingred]/resultscount
                if (thePercent < 0.20):
                    recommend_ls.append("Recipe Alert Thinks there is no issue using this ingredient")
                elif (thePercent < 0.40):
                    recommend_ls.append("Recipe Alert advise using less of this ingredient")
                elif (thePercent < 0.6):
                    recommend_ls.append("Recipe Alert advise against using this ingredient or switch out this ingredient")
                else:
                    recommend_ls.append("Recipe Alert advise against using this ingredient in the recipe")
            else:
                recommend_ls.append("Based on the metrics Recipe Alert Thinks there is no issue using this ingredient")
        print(warning_ingredient_amount_ls)


        result_warning_zip = zip(warning_ingredientCheckLs, warning_ingredient_amount_ls, picture_src_ls, recommend_ls)
            
        #avoid using a lot of x. based on the highest warning amount in the checck list.
        #give a percent lets just ball park 10 percent as safe still.

        #Recipe alert level: 
        #Recipe mark of approval.
        #by our metrics we deny or accept the recipe for this symptom.
        #consider taking out or lessen x ingredient to be on the safe side

        context = {"ingredientlist":ingredientlist, "symptom": symptom, "ing_string": ing_string, "title": title, "ref": ref, "totalSearches": totalSearches, "totalWarnings": totalWarnings, "foodIngredientWarnings": foodIngredientWarnings, "result_warning_zip": result_warning_zip}
        return render(request, 'accounts/symptom_search.html', context)
    return render(request, 'accounts/symptom_search.html', context)
    
    # context = {}

    # #just toast the warning? or just display it on the bottom. Warning for x symptom in this recipe. Do not reccomend for x symptom.
    # #or make a symptom search post form in the table row with the row ingredients and stuff?
    # #plug in all the ingredients, and the user enter symptom on search just stay on the same page and toast the message
    # #for warning? should be a form post.

    # #return render(request, 'accounts/symptom_search.html', context)
    # return render(request, 'accounts/symptom_search.html', context)

    # if (request.is_ajax()):
    #     ingredient_list = request.POST.get('ingredientlist', None)
    #     ing_str = request.POST.get('ing_str', None)
    #     symptom = request.POST('symptom', None)
    #     if (ingredient_list and ing_str and symptom):
    #         response = {
    #             'msg': 'Sucessfully got into if clause: ' + ing_str + symptom,

    #         }
    #         return JsonResponse(response)
    # response = {
    #         'msg': 'Didnt get into if'
    # }
    # return JsonResponse(response)



def saveRecipe(request):
    """save a recipe under the user's profile """
    #user = request.user #gets us the logged in user at anypoint in time.
    customer = request.user.customer #get the user's customer to access its customer's account
    customer_pk = request.user.customer.pk
    customer_name = request.user.customer.name


    
    #render the customer form
    # form = CustomerForm(instance=customer)

    ing_string = ""
    title =  ""
    ref = ""
    context = {}

    if request.method == 'POST':
        print()
        ing_string = request.POST['ing_string']
        title =  request.POST['titles']
        ref = request.POST['refs']

        # username = form.cleaned_data.get('username') #gets field of the form for username

        # group = Group.objects.get(name='customer') #get the customer group from our django admin models
        # user.groups.add(group) #add that group instance of customer to the user

        #     #assigning customer to our newly created user so it can do the functionality of a customer model
        # Customer.objects.create(user=user) #create a customer object for this user by setting the field user in Customer object to user


        #recipe_database_object = RecipeSavedDatabase.objects.create(name=title, recipe_url=ref, )

        # all_recipe_saved_database = RecipeSavedDatabase.objects.get() #getting all the object
        #num_results = User.objects.filter(email = cleaned_info['username']).count()
        all_recipe_saved_database = RecipeSavedDatabase.objects.all() #getting all the object
        num_results = RecipeSavedDatabase.objects.filter(name=title).count() #check if this exists

        if (num_results == 0):
            #if there is none in our database for this recipe. Create one.
            RecipeSavedDatabase.objects.create(name=title, recipe_url=ref, ingredients=ing_string) #create this object in databaseinit user tags to ing_string first
        #after created recipe. get it
        recipe_database_object = RecipeSavedDatabase.objects.get(name=title) #get that object we just created in the saveddatabaseobject


        if (RecipeSavedProfile.objects.filter(name=title, customer=customer).count() == 0):
            RecipeSavedProfile.objects.create(name=title, customer=customer, recipe=recipe_database_object)
        
        recipe_save_object = RecipeSavedProfile.objects.filter(recipe=recipe_database_object)
        recipe_save_object2 = RecipeSavedProfile.objects.get(name=title, customer=customer, recipe=recipe_database_object)

        # print(recipe_database_object.pk)
        print(recipe_database_object.name)
        # print(recipe_save_object.recipe.pk)
        print(recipe_save_object2.recipe.pk)


        context = {"customer":customer, "customer_pk": customer_pk, "customer_name": customer_name}
        return render(request,'accounts/recipe_save.html', context)


    return render(request,'accounts/recipe_save.html', context)
    

def delete_saved_database(request):
    RecipeSavedDatabase.objects.all().delete()
    context = {}
    return render(request,'accounts/empty.html', context)

def delete_saved_profile(request):
    context = {}
    RecipeSavedProfile.objects.all().delete()
    return render(request,'accounts/empty.html', context)


def javascript_test(request):

    context = {}
    return render(request, 'accounts/javascript_test.html', context)


def showUserSubmittedInfo(request):
    """ Show a page for stats on user submitted tags on the recipe """

    customer = request.user.customer #get the user's customer to access its customer's account
    customer_pk = request.user.customer.pk
    customer_name = request.user.customer.name


    context = {}
    if (request.method == 'POST'):
        print()
        name = request.POST['name']
        recipe_url = request.POST['refs']

        theSavedDatabase = RecipeSavedDatabase.objects.get(name=name, recipe_url=recipe_url) #get the database reference of the recipe
        theSavedRecipe = RecipeSavedProfile.objects.get(recipe=theSavedDatabase, customer=customer) #get the saved profile recipe version


        databaseUserTags = theSavedDatabase.get_user_tags() #get the list of database user tags
        profileUserTags = theSavedRecipe.get_user_tags() #get the list of tags the user made for this recipe

        if(databaseUserTags == None):
            databaseUserTags = []
        if (profileUserTags == None):
            profileUserTags = [] #if empty just do this


        databaseTagSize = len(databaseUserTags)
        profileTagSize = len(profileUserTags)

        uniqueUserDatabaseTags = []
        uniqueUserDatabaseTagsDict = {}
        for tag in databaseUserTags:
            #check if so we can get unique tag count
            if (tag not in uniqueUserDatabaseTags):
                uniqueUserDatabaseTags.append(tag) #append it to the list
                uniqueUserDatabaseTagsDict[tag] = 1
            else:
                uniqueUserDatabaseTagsDict[tag] += 1 
        
        uniqueUserDatabaseTagsCount = []
        for tag in uniqueUserDatabaseTags:
            uniqueUserDatabaseTagsCount.append(uniqueUserDatabaseTagsDict[tag]) #parallel array so we can zip up the unique database tags with its count

        uniqueUserDatabaseTagsZipped = zip(uniqueUserDatabaseTags, uniqueUserDatabaseTagsCount) #zip up the parallel arrays
        

        json_uniqueUserDatabaseTags = json.dumps(uniqueUserDatabaseTags)
        json_uniqueUserDatabaseTagsCount = json.dumps(uniqueUserDatabaseTagsCount)
        
        context = {"customer_name": customer_name, "theSavedDatabase": theSavedDatabase, "databaseTagSize":databaseTagSize, "databaseUserTags":databaseUserTags, 
            "profileTagSize":profileTagSize, "profileUserTags":profileUserTags, "uniqueUserDatabaseTags": uniqueUserDatabaseTags, "uniqueUserDatabaseTagsCount":uniqueUserDatabaseTagsCount, "uniqueUserDatabaseTagsZipped":uniqueUserDatabaseTagsZipped,
            "json_uniqueUserDatabaseTags":json_uniqueUserDatabaseTags, "json_uniqueUserDatabaseTagsCount":json_uniqueUserDatabaseTagsCount
            }

        return render(request, 'accounts/show_user_tags.html', context)



    #if not post redirect back here to same page 
    url = reverse('user_page')
    return redirect(url)
    # return userPage(request) #defaults to basic page

def addUserTag(request):
    """ Add a symptom tag to a recipe """
    customer = request.user.customer #get the user's customer to access its customer's account
    customer_pk = request.user.customer.pk
    customer_name = request.user.customer.name

    context = {}
    if (request.method == 'POST'):
        print()
        #find the saved object databse and the profile one.
        symptom = str(request.POST['symptom'])
        name = request.POST['name']
        recipe_url = request.POST['refs']

        theSavedDatabase = RecipeSavedDatabase.objects.get(name=name, recipe_url=recipe_url) #get the database reference of the recipe
        theSavedRecipe = RecipeSavedProfile.objects.get(recipe=theSavedDatabase, customer=customer) #get the saved profile recipe version

        databaseUserTags = theSavedDatabase.get_user_tags() #get the list of database user tags
        profileUserTags = theSavedRecipe.get_user_tags() #get the list of tags the user made for this recipe

        #loop through profile user tag if the tag exist dont add it, else add it.
        profileTagExists = False

        if(databaseUserTags == None):
            databaseUserTags = []
        if (profileUserTags == None):
            profileUserTags = [] #if empty just do this

        for tag in profileUserTags:
            if (tag.upper() == symptom.upper() ):
                #if we find match then say it is True
                profileTagExists = True
                break

        databaseTagExists = False
        for tag in databaseUserTags:
            if (tag.upper() == symptom.upper() ):
                #if we find match then say it is True
                databaseTagExists = True
                break
                #we allow duplicates but just check it case

        if (not profileTagExists):
            #check the profile one if the user added it before, not then add it to the database, allows tag dupes but one user submitted tag per recipe per user.
            theSavedDatabase.set_user_tags(symptom.upper())#add the symptom tag
            theSavedDatabase.save() #save the database object

        if (not profileTagExists):
            #if tag doesnt exist in profile recipe save we add it
            theSavedRecipe.set_user_tags(symptom.upper()) #add the symptom tag
            theSavedRecipe.save() # save the profile recipe object


    #if not post redirect back here to same page 
    url = reverse('user_page')
    return redirect(url)


def deleteSavedRecipe(request):
    """ Delete a RecipeSavedprofile object from the user """

    customer = request.user.customer #get the user's customer to access its customer's account
    customer_pk = request.user.customer.pk
    customer_name = request.user.customer.name

    if (request.method == 'POST'):
        print()

        name = request.POST['name']
        recipe_url = request.POST['refs']

        theSavedDatabase = RecipeSavedDatabase.objects.get(name=name, recipe_url=recipe_url) #get the database reference of the recipe
        theSavedRecipe = RecipeSavedProfile.objects.get(recipe=theSavedDatabase, customer=customer) #get the saved profile recipe version

        theSavedRecipe.delete() #delete this saved entry
        
        
        


    url = reverse('user_page')
    return redirect(url)
