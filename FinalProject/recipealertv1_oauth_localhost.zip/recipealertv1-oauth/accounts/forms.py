from django.forms import ModelForm
from .models import *

#needed for user auth
from django.contrib.auth.forms import UserCreationForm
from django import forms
from django.contrib.auth.models import User #importing the User model provided by django

#CustomerForm OrderForm etc... name of it
class OrderForm(ModelForm):

    class Meta:
        model = Order
        fields = '__all__' #allows all the fields of Order. Make a form with all of these fields

#user creation form
class CreateUserForm(UserCreationForm):
    class Meta:
        model = User
        fields = ['username', 'email', 'password1', 'password2'] #django documentation fields from UserCreationForm

#User
class CustomerForm(ModelForm):
    class Meta:
        model = Customer
        fields = '__all__'
        exclude = ['user'] #not allow the customer to mess with associating with another user after creation of account
                            #important so customer cant just hippity hop to another related user

# class CreateRecipeForm(ModelForm):
#     class Meta:
#         model = RecipeSavedDatabase
#         fields = '__all__' #allows all the fields. Make a form with all of these fields


# class SaveRecipeForm(ModelForm):
#     class Meta:
#         model = RecipeSavedProfile
#         fields = '__all__' #allows all the fields. Make a form with all of these fields


class SearchRecipeForm(ModelForm):
    class Meta:
        model = SearchRecipe
        fields = '__all__'

class SearchSymptomForm(ModelForm):
    class Meta:
        model = SearchSymptom
        fields = '__all__'
        exclude = ['ingredients'] #because we will prefill it base on the recipe





class RecipeSavedDatabaseForm(ModelForm):
    class Meta:
        model = RecipeSavedDatabase
        fields = '__all__'

        
class RecipeSavedProfileForm(ModelForm):
    class Meta:
        model = RecipeSavedProfile
        fields = '__all__'





# class SearchSymptomForm():
#or just use the form field itself

