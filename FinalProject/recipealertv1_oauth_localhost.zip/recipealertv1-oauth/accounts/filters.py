import django_filters
from django_filters import DateFilter, CharFilter

from .models import *


class OrderFilter(django_filters.FilterSet):

    start_date = DateFilter(field_name="date_created", lookup_expr='gte') #lookup is greater than or equal to
    end_date = DateFilter(field_name="date_created", lookup_expr='lte') #lookup less than or equal to
    note = CharFilter(field_name='note', lookup_expr='icontains')
    class Meta:
        model = Order # we are building this filter for model
        fields ='__all__'
        exclude = ['customer', 'date_created'] #exclude these fields from all the fields in Order model
