from django.contrib import admin

# Register your models here.

from .models import *

admin.site.register(Customer) #registering our customer model
admin.site.register(Product) #registering our product model
admin.site.register(Order) #registering our order model
admin.site.register(Tag) #registering our order model
admin.site.register(RecipeSavedDatabase)
admin.site.register(RecipeSavedProfile)
