from django.http import HttpResponse
from django.shortcuts import redirect

#decorators to deal with middleware responses
#such as not allowing users to go to login page if logged in already

#Building decorators...
#A decorators is a function that takes in another function as a parameter 
#and lets us add additional functionality before the original function is called
#the func it takes it doesnt get ran until the wrapper function is ran.


def unauthenticated_user(view_func):
    def wrapper_func(request, *args, **kwargs):
        #if user is logged in just log the user in, to restrict access to login and registration page for logged in users
        if request.user.is_authenticated:
            #we can access user this way because django does it for us in request
            return redirect('home') #redirect user to home page
        else:
            #if user is not authenticated just call the original function
            return view_func(request, *args, **kwargs)

    return wrapper_func

def allowed_users(allowed_roles=[]):
    def decorator(view_func):
        def wrapper_func(request, *args, **kwargs):
            #print("testing allowed roles:", allowed_roles)
            group = None
            if request.user.groups.exists():
                group = request.user.groups.all()[0].name #get the request of the groups name
            
            if group in allowed_roles:
                return view_func(request, *args, **kwargs)
            #else
            return HttpResponse("Unauthorized access. User permission insufficient")
        return wrapper_func
    return decorator

def admin_only(view_func):
    def wrapper_func(request, *args, **kwargs):
        group = None
        if request.user.groups.exists():
            group = request.user.groups.all()[0].name #get the request of the groups name
        if group == 'customer':
            return redirect('user_page')
        if group == 'admin':
            return view_func(request, *args, **kwargs)
    return wrapper_func