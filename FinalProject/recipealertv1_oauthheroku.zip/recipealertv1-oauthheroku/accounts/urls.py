from django.urls import path
# from . import views

from .views import *

urlpatterns = [
    # path('', views.home, name='home'),
    # path('', views.products, name='products'),
    # path('', views.costumer, name='costumer')

    path('javascript_test/', javascript_test, name='js_test'),


    path('', home, name='home'),
    # path('products/', products, name='products'), #urls from the project we built on top of 
    # path('customer/<str:pk>', customer, name='customer'),
    # path('create_order/', createOrder, name='create_order'),
    # path('create_order/<str:pk>', createOrder, name='create_order'), #pk is the id of the customer here
    # path('update_order/<str:pk>', updateOrder, name='update_order'), #pk is id of the order
    # path('delete_order/<str:pk>', deleteOrder, name='delete_order'), #pk is id of the order


    path('account/', accountSettings, name="account"),
    path('register/', registerPage, name='register'),

    path('oauth_redirect_page/', oauthRedirectPage, name='oauth_redirect_page'), #for registering to model.

    path('login/', loginPage, name='login'),
    path('logout/', logoutUser, name='logout'),   
    path('user/', userPage, name='user_page'),
    path('user/', userPage2, name='user_page2'),

    path('recipe_search/', searchRecipe, name='search_recipe'), 
    path('recipe_display_all/', displayAllRecipes, name='display_all_recipe'),   
    path('recipe_display/', displayRecipe, name='display_recipe'), #from the row context stuff pass this into this html so it can display it
    path('recipe_search/symptom_search', searchSymptom, name='search_symptom'),
    path('recipe_search/save_recipe', saveRecipe, name='save_recipe'),
    # path('delete_saved_profile/', delete_saved_profile, name='delete_saved_profile'),

    path('show_user_submitted_info/', showUserSubmittedInfo, name='show_user_submitted_info'),
    path('add_user_tag/', addUserTag, name='add_user_tag'),
    path('deleteSavedRecipe/', deleteSavedRecipe, name='delete_saved_recipe'),

]