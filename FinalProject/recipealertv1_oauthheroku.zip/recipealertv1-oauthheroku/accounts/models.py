from django.db import models
from django.contrib.auth.models import User #import the user model already built by djnago
# Create your models here.


class Customer(models.Model):

    user = models.OneToOneField(User, null=True, blank=True, on_delete=models.CASCADE) #null is true b.c we have some cstuomers already, one to one profile
    name = models.CharField(max_length=200, null=True, blank=True, default="") #default value of null if not exist
    phone = models.CharField(max_length=200, null=True, blank=True, default="")
    email = models.CharField(max_length=200, null=True, blank=True, default="")
    profile_pic = models.ImageField(default="lemon.jpg",null=True, blank=True)
    date_created = models.DateTimeField(auto_now_add=True, null=True)
    # recipe_saved = models.ManyToManyField(RecipeSavedProfile)
    def __str__(self):
        return f"{self.name}"


class Tag(models.Model):
    """ Tag for types of product, like tag of genre etc"""
    name = models.CharField(max_length=200, null=True) #default value of null if not exist
    def __str__(self):
        return f"{self.name}"


#similar to products model
#this will be the version saved in the data base
class RecipeSavedDatabase(models.Model):
    name = models.CharField(max_length=200, null=True, blank=True, default="")
    recipe_url = models.URLField(null=True, blank=True, default="") #url for this recipe to get directions etc
    tags = models.ManyToManyField(Tag, blank=True) #tag i.e. symptoms
    user_tags = models.TextField(null=True, blank=True, default="") # JSON-serialized (text) version of your list, this will be a list of tags submitted by users, also doing it text will handle duplicate submissions
    ingredients = models.CharField(max_length=255, null=True, blank=True, default="")
    date_created = models.DateTimeField(auto_now_add=True, null=True)

    def __str__(self):
        return f"{self.name}"

    def set_user_tags(self, element):
        if self.user_tags:
            self.user_tags = self.user_tags + "," + element
        else:
            self.user_tags = element

    def get_user_tags(self):
        if self.user_tags:
            return self.user_tags.split(",")
        else:
            None

#this will be the version saved in the profile.
class RecipeSavedProfile(models.Model):
    name = models.CharField(max_length=200, null=True, blank=True, default="")
    customer = models.ForeignKey(Customer, null=True, on_delete=models.SET_NULL)#one to many relationship, on delete if customer is deleted we set the customer value to null for this order
    recipe = models.ForeignKey(RecipeSavedDatabase, null=True, on_delete=models.SET_NULL) #one to many relationship
    date_created = models.DateTimeField(auto_now_add=True, null=True)
    tags = models.ManyToManyField(Tag, blank=True)
    user_tags = models.TextField(null=True, blank=True, default="")#see the tag that the user submitted in its own profile
    comments = models.CharField(max_length=1000, null=True, blank=True, default="")
    def __str__(self):
        return f"{self.name}"

    def set_user_tags(self, element):
        if self.user_tags:
            self.user_tags = self.user_tags + "," + element
        else:
            self.user_tags = element

    def get_user_tags(self):
        if self.user_tags:
            return self.user_tags.split(",")
        else:
            None

#for searching stuff
class SearchRecipe(models.Model):
    dishname = models.CharField(max_length=200, null=True, blank=True, default='') #dish you want to make
    ingredient = models.CharField(max_length=200, null=True, blank=True, default='') #ingredient you want to make it with

class SearchSymptom(models.Model):
    ingredients = models.TextField(null=True) #prefill this, and loop across to check for symptom with fda. api.
    symptom = models.CharField(max_length=200, null=True)


#models not needed
class Product(models.Model):
    CATEGORY = (
        ('Indoor', 'Indoor'),
        ('Out Door', 'Out Door'),
    )
    name = models.CharField(max_length=200, null=True)
    price = models.FloatField(null=True)
    category = models.CharField(max_length=200, null=True, choices=CATEGORY)
    description = models.CharField(max_length=200, null=True, blank=True) #blank=true means it could be left blank
    date_created = models.DateTimeField(auto_now_add=True, null=True)
    tags = models.ManyToManyField(Tag)
    def __str__(self):
        return f"{self.name}"


class Order(models.Model):

    STATUS = (
        ('Pending', 'Pending'),
        ('Out for delivery', 'Out for delivery'),
        ('Delivered', 'Delivered'),
    )
    customer = models.ForeignKey(Customer, null=True, on_delete=models.SET_NULL)#one to many relationship, on delete if customer is deleted we set the customer value to null for this order
    product = models.ForeignKey(Product, null=True, on_delete=models.SET_NULL) #one to many relationship
    date_created = models.DateTimeField(auto_now_add=True, null=True)
    status = models.CharField(max_length=200, null=True, choices=STATUS) #give status a dropdown menu of choices to pick from if in dropdown
    
    note = models.CharField(max_length=1000, null=True)
    
    def __str__(self):
        return f"{self.product.name}"





#keep the customer model because it does a lot of what we want already.
#recipe model goes here similar to product model. On save. Saves to Products database or look for name in data base first and reference it. If not in database save it.
#recipe has fields, recipe name, recipe id?, recipe ingredients, recipe directions, tagged symptoms from the other api, recipe comments from user which takes in a comment model,
#tag model is usable for tagging symptoms

#checking recipe name first because its given in the json like this Onion-Cheese-Omelet-15248,  Dads-Chili-Cheese-Omelet-146498, 

#update saved recipe, can be saved for good or bad reasons.
#Recommendation, it contains "Ingredient" which has a possibility of "symptom" symptoms.
#User Recommendation of this recipe for symptom, None for none, x percent based on One user if contains that symptom.